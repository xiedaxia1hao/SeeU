from django.apps import AppConfig


class SeeuappConfig(AppConfig):
    name = 'SEEUApp'
